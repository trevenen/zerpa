# Container SBOM & Vulnerability Scanner (Cross-Architecture Podman Workflow)

This project simulates a GitLab CI pipeline **locally** using **Podman** to:

- Pull a list of example container images
- Generate SBOMs using [Syft](https://github.com/anchore/syft)
- Scan for vulnerabilities using [Grype](https://github.com/anchore/grype)
- Create fixed images with vulnerabilities patched
- Optionally push results to **Snowflake** for analysis

> 🐳 This workflow uses **Podman**, not Docker, for container operations.
> 
> 🖥️ Cross-architecture support ensures it works on any laptop (x86_64, ARM64, etc.)

---

## 🔧 Prerequisites

Ensure the following are installed on macOS:

- [**Podman**](https://podman.io/getting-started/installation)
- [**Syft**](https://github.com/anchore/syft#installation)
- [**Grype**](https://github.com/anchore/grype#installation)
- [**Python 3.8+**](https://www.python.org/downloads/)
    - Install Snowflake connector:
      ```bash
      pip install snowflake-connector-python
      ```

---

## 🚀 Running the Scan Locally

Run the script to scan containers:

```bash
chmod +x local_scan.sh
./local_scan.sh
```

## 🛠️ Creating Fixed Images

After scanning, you can create fixed images with vulnerabilities patched:

```bash
chmod +x fix_vulnerabilities.sh
./fix_vulnerabilities.sh
```

This will:
1. Detect your system architecture automatically
2. Create Dockerfiles that update all packages in the base images
3. Build new fixed images using Podman with appropriate platform flags
4. Scan the fixed images for remaining vulnerabilities
5. Generate an updated HTML report comparing original and fixed images

## 🖥️ Cross-Architecture Support

This project has been enhanced to work on any architecture:

- **Automatic Architecture Detection**: Automatically detects your system's architecture (x86_64, ARM64, etc.)
- **Platform-Specific Builds**: Uses `--platform` flags with Podman when supported
- **Fallback Mechanisms**: Gracefully falls back to native architecture if platform-specific operations fail
- **Compatibility Checks**: Verifies tool support for platform flags before attempting to use them

The scripts will work on:
- x86_64 / AMD64 systems
- ARM64 / AArch64 systems (like Apple Silicon Macs)
- ARMv7 systems
- Other architectures with appropriate fallbacks
