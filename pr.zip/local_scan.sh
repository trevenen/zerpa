#!/bin/bash

set -uo pipefail

CONTAINERS=(
  nginx
  debian:bullseye
  python
  fluentd
  fluent/fluent-bit
  mcr.microsoft.com/dotnet/runtime:8.0
  mcr.microsoft.com/dotnet/aspnet:8.0-noble-chiseled
)

# Detect host architecture
HOST_ARCH=$(uname -m)
case "$HOST_ARCH" in
  x86_64)
    PLATFORM="linux/amd64"
    ;;
  aarch64|arm64)
    PLATFORM="linux/arm64"
    ;;
  armv7l)
    PLATFORM="linux/arm/v7"
    ;;
  *)
    echo "Warning: Unknown architecture $HOST_ARCH, defaulting to amd64"
    PLATFORM="linux/amd64"
    ;;
esac

echo "Detected host architecture: $HOST_ARCH (Platform: $PLATFORM)"

mkdir -p outputs/syft outputs/grype bin cache
SUCCESSFUL_IMAGES=()
CACHE_FILE="cache/pulled_images.txt"

# Add local bin to PATH
export PATH="$PWD/bin:$PATH"

# Ensure syft and grype are available
if ! command -v syft &>/dev/null; then
  echo "Installing Syft..."
  curl -sSfL https://raw.githubusercontent.com/anchore/syft/main/install.sh | sh -s -- -b "$PWD/bin"
fi

if ! command -v grype &>/dev/null; then
  echo "Installing Grype..."
  curl -sSfL https://raw.githubusercontent.com/anchore/grype/main/install.sh | sh -s -- -b "$PWD/bin"
fi

# Load cached images
CACHED_IMAGES=()
if [[ -f "$CACHE_FILE" ]]; then
  while IFS= read -r line; do
    CACHED_IMAGES+=("$line")
  done < "$CACHE_FILE"
fi

echo "Pulling images using Podman..."
for image in "${CONTAINERS[@]}"; do
  if [[ ${#CACHED_IMAGES[@]} -gt 0 ]] && [[ " ${CACHED_IMAGES[*]} " =~ " ${image} " ]]; then
    echo "→ Using cached $image"
    SUCCESSFUL_IMAGES+=("$image")
  else
    echo "→ Pulling $image for platform $PLATFORM"

    # Check if podman supports the --platform flag
    if podman pull --help 2>&1 | grep -q -- "--platform"; then
      # Podman supports platform flag
      if podman pull --platform="$PLATFORM" "$image" 2>/dev/null; then
        echo "$image" >> "$CACHE_FILE"
        SUCCESSFUL_IMAGES+=("$image")
        echo "  ✅ Success (pulled for $PLATFORM)"
      else
        echo "  ❌ Failed to pull $image for $PLATFORM"
        echo "  ⚠️ Trying without platform specification..."
        if podman pull "$image" 2>/dev/null; then
          echo "$image" >> "$CACHE_FILE"
          SUCCESSFUL_IMAGES+=("$image")
          echo "  ✅ Success (pulled for native architecture)"
        else
          echo "  ❌ Failed to pull $image - skipping"
        fi
      fi
    else
      # Older podman version without platform support
      echo "  ⚠️ Your podman version doesn't support the --platform flag, pulling for native architecture"
      if podman pull "$image" 2>/dev/null; then
        echo "$image" >> "$CACHE_FILE"
        SUCCESSFUL_IMAGES+=("$image")
        echo "  ✅ Success (pulled for native architecture)"
      else
        echo "  ❌ Failed to pull $image - skipping"
      fi
    fi
  fi
done

if [[ ${#SUCCESSFUL_IMAGES[@]} -eq 0 ]]; then
  echo "❌ No images available for scanning"
  exit 1
fi

echo "Running Syft on ${#SUCCESSFUL_IMAGES[@]} images..."
for image in "${SUCCESSFUL_IMAGES[@]}"; do
  safe_name=$(echo "$image" | tr '/:' '__')
  output_file="outputs/syft/${safe_name}_syft.json"

  if [[ -f "$output_file" ]]; then
    echo "→ Using cached Syft results for $image"
  else
    echo "→ Syft scan for $image (architecture: $HOST_ARCH)"

    # Try with --platform flag if syft supports it
    if syft --help 2>&1 | grep -q -- "--platform"; then
      echo "  ℹ️ Syft supports platform specification, using $PLATFORM"
      if syft --platform="$PLATFORM" "$image" -o json > "$output_file" 2>/dev/null; then
        echo "  ✅ Success with platform specification"
      else
        echo "  ⚠️ Failed with platform specification, trying without..."
        if syft "$image" -o json > "$output_file" 2>/dev/null; then
          echo "  ✅ Success without platform specification"
        else
          echo "  ❌ Syft scan failed for $image"
          echo "  ℹ️ Creating empty file to avoid repeated failures"
          echo "{}" > "$output_file"
        fi
      fi
    else
      # Syft doesn't support platform flag
      if syft "$image" -o json > "$output_file" 2>/dev/null; then
        echo "  ✅ Success"
      else
        echo "  ❌ Syft scan failed for $image"
        echo "  ℹ️ Creating empty file to avoid repeated failures"
        echo "{}" > "$output_file"
      fi
    fi
  fi
done

echo "Running Grype on ${#SUCCESSFUL_IMAGES[@]} images..."
for image in "${SUCCESSFUL_IMAGES[@]}"; do
  safe_name=$(echo "$image" | tr '/:' '__')
  output_file="outputs/grype/${safe_name}_grype.json"

  if [[ -f "$output_file" ]]; then
    echo "→ Using cached Grype results for $image"
  else
    echo "→ Grype scan for $image (architecture: $HOST_ARCH)"

    # Try with --platform flag if grype supports it
    if grype --help 2>&1 | grep -q -- "--platform"; then
      echo "  ℹ️ Grype supports platform specification, using $PLATFORM"
      if grype --platform="$PLATFORM" "$image" -o json > "$output_file" 2>/dev/null; then
        echo "  ✅ Success with platform specification"
      else
        echo "  ⚠️ Failed with platform specification, trying without..."
        if grype "$image" -o json > "$output_file" 2>/dev/null; then
          echo "  ✅ Success without platform specification"
        else
          echo "  ❌ Grype scan failed for $image"
          echo "  ℹ️ Creating empty file to avoid repeated failures"
          echo "{\"matches\": []}" > "$output_file"
          echo "  ℹ️ To retry manually, run:"
          echo "      grype \"$image\" -o json > \"$output_file\""
        fi
      fi
    else
      # Grype doesn't support platform flag
      if grype "$image" -o json > "$output_file" 2>/dev/null; then
        echo "  ✅ Success"
      else
        echo "  ❌ Grype scan failed for $image"
        echo "  ℹ️ Creating empty file to avoid repeated failures"
        echo "{\"matches\": []}" > "$output_file"
        echo "  ℹ️ To retry manually, run:"
        echo "      grype \"$image\" -o json > \"$output_file\""
      fi
    fi
  fi
done

echo "✅ Scanning complete. Results are in outputs/{syft,grype}/"

echo "Generating vulnerability report..."
python3 generate_report.py

echo "🌐 Open vulnerability_report.html in your browser to view critical vulnerabilities"
