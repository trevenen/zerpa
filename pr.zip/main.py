import os, json
import snowflake.connector

def get_connection():
    return snowflake.connector.connect(
        user=os.environ['SNOWFLAKE_USER'],
        password=os.environ['SNOWFLAKE_PASSWORD'],
        account=os.environ['SNOWFLAKE_ACCOUNT'],
        warehouse=os.environ['SNOWFLAKE_WAREHOUSE'],
        database=os.environ['SNOWFLAKE_DATABASE'],
        schema=os.environ['SNOWFLAKE_SCHEMA']
    )

def upload_json(cur, path, report_type):
    with open(path) as f:
        data = json.load(f)
    name = os.path.basename(path).replace(".json", "")
    cur.execute(
        "INSERT INTO sbom_data(id, type, data) VALUES (%s, %s, PARSE_JSON(%s))",
        (name, report_type, json.dumps(data))
    )

def main():
    conn = get_connection()
    cur = conn.cursor()
    for folder, rtype in [('outputs/syft', 'sbom'), ('outputs/grype', 'vuln')]:
        for fname in os.listdir(folder):
            if fname.endswith('.json'):
                upload_json(cur, os.path.join(folder, fname), rtype)
    cur.close()
    conn.close()

if __name__ == "__main__":
    main()
