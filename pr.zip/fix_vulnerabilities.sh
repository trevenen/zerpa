#!/bin/bash

set -uo pipefail

# Define the containers array directly
CONTAINERS=(
  nginx
  debian:bullseye
  python
  fluentd
  fluent/fluent-bit
  mcr.microsoft.com/dotnet/runtime:8.0
  mcr.microsoft.com/dotnet/aspnet:8.0-noble-chiseled
)

# Detect host architecture
HOST_ARCH=$(uname -m)
case "$HOST_ARCH" in
  x86_64)
    PLATFORM="linux/amd64"
    ;;
  aarch64|arm64)
    PLATFORM="linux/arm64"
    ;;
  armv7l)
    PLATFORM="linux/arm/v7"
    ;;
  *)
    echo "Warning: Unknown architecture $HOST_ARCH, defaulting to amd64"
    PLATFORM="linux/amd64"
    ;;
esac

echo "Detected host architecture: $HOST_ARCH (Platform: $PLATFORM)"

# Directory for Dockerfiles
mkdir -p fixed_images

echo "Creating fixed images using Podman..."
for image in "${CONTAINERS[@]}"; do
  echo "→ Processing $image"
  safe_name=$(echo "$image" | tr '/:' '__')

  # Create a directory for each image
  mkdir -p "fixed_images/$safe_name"

  # Create a Dockerfile that updates all packages
  case "$image" in
    *debian*|*ubuntu*)
      cat > "fixed_images/$safe_name/Dockerfile" <<EOF
FROM $image
RUN apt-get update && \
    apt-get upgrade -y && \
    apt-get clean && \
    rm -rf /var/lib/apt/lists/*
EOF
      ;;
    *alpine*)
      cat > "fixed_images/$safe_name/Dockerfile" <<EOF
FROM $image
RUN apk update && \
    apk upgrade && \
    rm -rf /var/cache/apk/*
EOF
      ;;
    *fedora*|*centos*|*rhel*)
      cat > "fixed_images/$safe_name/Dockerfile" <<EOF
FROM $image
RUN dnf update -y && \
    dnf clean all
EOF
      ;;
    *nginx*)
      cat > "fixed_images/$safe_name/Dockerfile" <<EOF
FROM $image
RUN apt-get update && \
    apt-get upgrade -y && \
    apt-get clean && \
    rm -rf /var/lib/apt/lists/*
EOF
      ;;
    *python*)
      cat > "fixed_images/$safe_name/Dockerfile" <<EOF
FROM $image
RUN apt-get update && \
    apt-get upgrade -y && \
    apt-get clean && \
    rm -rf /var/lib/apt/lists/*
EOF
      ;;
    *fluent*)
      cat > "fixed_images/$safe_name/Dockerfile" <<EOF
FROM $image
RUN apt-get update || apk update && \
    apt-get upgrade -y || apk upgrade && \
    apt-get clean || true && \
    rm -rf /var/lib/apt/lists/* || true && \
    rm -rf /var/cache/apk/* || true
EOF
      ;;
    *dotnet*|*mcr.microsoft.com*)
      cat > "fixed_images/$safe_name/Dockerfile" <<EOF
FROM $image
RUN apt-get update || apk update || dnf update -y && \
    apt-get upgrade -y || apk upgrade || dnf upgrade -y && \
    apt-get clean || true && \
    rm -rf /var/lib/apt/lists/* || true && \
    rm -rf /var/cache/apk/* || true
EOF
      ;;
    *)
      echo "  ⚠️ Unknown image type, using generic update strategy"
      cat > "fixed_images/$safe_name/Dockerfile" <<EOF
FROM $image
RUN apt-get update || apk update || dnf update -y || yum update -y && \
    apt-get upgrade -y || apk upgrade || dnf upgrade -y || yum upgrade -y && \
    apt-get clean || true && \
    rm -rf /var/lib/apt/lists/* || true && \
    rm -rf /var/cache/apk/* || true
EOF
      ;;
  esac

  # Build the fixed image using podman
  fixed_tag="${image}-fixed"
  echo "→ Building fixed image: $fixed_tag for platform $PLATFORM"

  # Check if podman supports the --platform flag
  if podman build --help 2>&1 | grep -q -- "--platform"; then
    # Podman supports platform flag
    if podman build --platform="$PLATFORM" -t "$fixed_tag" -f "fixed_images/$safe_name/Dockerfile" "fixed_images/$safe_name" 2>&1 | tee /tmp/build.log; then
      echo "  ✅ Successfully built $fixed_tag for $PLATFORM"
    else
      build_error=$(cat /tmp/build.log)
      echo "  ❌ Failed to build $fixed_tag for $PLATFORM"
      echo "  ⚠️ Trying without platform specification..."

      if podman build -t "$fixed_tag" -f "fixed_images/$safe_name/Dockerfile" "fixed_images/$safe_name" 2>&1 | tee /tmp/build.log; then
        echo "  ✅ Successfully built $fixed_tag (native architecture)"
      else
        build_error=$(cat /tmp/build.log)
        echo "  ❌ Failed to build $fixed_tag"

        # Check for specific error conditions
        if echo "$build_error" | grep -q "executable file .*/bin/sh. not found"; then
          echo "  ℹ️ Error: The base image doesn't have /bin/sh which is required for package updates"
          echo "  ℹ️ This is common with minimal or distroless images"
          echo "  ℹ️ Creating a copy of the original image as a fallback"

          # Create a copy of the original image as a fallback
          if podman tag "$image" "$fixed_tag"; then
            echo "  ✅ Created $fixed_tag as a copy of the original image"
            echo "  ⚠️ Note: No vulnerabilities were fixed in this image"
          else
            echo "  ❌ Failed to create a copy of the original image"
            continue
          fi
        else
          echo "  ℹ️ Build error details:"
          echo "$build_error" | sed 's/^/    /'
          continue
        fi
      fi
    fi
  else
    # Older podman version without platform support
    echo "  ⚠️ Your podman version doesn't support the --platform flag, building for native architecture"
    if podman build -t "$fixed_tag" -f "fixed_images/$safe_name/Dockerfile" "fixed_images/$safe_name" 2>&1 | tee /tmp/build.log; then
      echo "  ✅ Successfully built $fixed_tag (native architecture)"
    else
      build_error=$(cat /tmp/build.log)
      echo "  ❌ Failed to build $fixed_tag"

      # Check for specific error conditions
      if echo "$build_error" | grep -q "executable file .*/bin/sh. not found"; then
        echo "  ℹ️ Error: The base image doesn't have /bin/sh which is required for package updates"
        echo "  ℹ️ This is common with minimal or distroless images"
        echo "  ℹ️ Creating a copy of the original image as a fallback"

        # Create a copy of the original image as a fallback
        if podman tag "$image" "$fixed_tag"; then
          echo "  ✅ Created $fixed_tag as a copy of the original image"
          echo "  ⚠️ Note: No vulnerabilities were fixed in this image"
        else
          echo "  ❌ Failed to create a copy of the original image"
          continue
        fi
      else
        echo "  ℹ️ Build error details:"
        echo "$build_error" | sed 's/^/    /'
        continue
      fi
    fi
  fi

  # Scan the fixed image for vulnerabilities
  echo "→ Scanning fixed image: $fixed_tag"
  fixed_safe_name=$(echo "$fixed_tag" | tr '/:' '__')

  # Run Syft on the fixed image
  echo "  → Running Syft on $fixed_tag (architecture: $HOST_ARCH)"

  # Try with --platform flag if syft supports it
  if syft --help 2>&1 | grep -q -- "--platform"; then
    echo "    ℹ️ Syft supports platform specification, using $PLATFORM"
    if syft --platform="$PLATFORM" "$fixed_tag" -o json > "outputs/syft/${fixed_safe_name}_syft.json" 2>/dev/null; then
      echo "    ✅ Syft scan successful with platform specification"
    else
      echo "    ⚠️ Failed with platform specification, trying without..."
      if syft "$fixed_tag" -o json > "outputs/syft/${fixed_safe_name}_syft.json" 2>/dev/null; then
        echo "    ✅ Syft scan successful without platform specification"
      else
        echo "    ❌ Syft scan failed for $fixed_tag"
        echo "    ℹ️ Creating empty file to avoid repeated failures"
        echo "{}" > "outputs/syft/${fixed_safe_name}_syft.json"
      fi
    fi
  else
    # Syft doesn't support platform flag
    if syft "$fixed_tag" -o json > "outputs/syft/${fixed_safe_name}_syft.json" 2>/dev/null; then
      echo "    ✅ Syft scan successful"
    else
      echo "    ❌ Syft scan failed for $fixed_tag"
      echo "    ℹ️ Creating empty file to avoid repeated failures"
      echo "{}" > "outputs/syft/${fixed_safe_name}_syft.json"
    fi
  fi

  # Run Grype on the fixed image
  echo "  → Running Grype on $fixed_tag (architecture: $HOST_ARCH)"

  # Try with --platform flag if grype supports it
  if grype --help 2>&1 | grep -q -- "--platform"; then
    echo "    ℹ️ Grype supports platform specification, using $PLATFORM"
    if grype --platform="$PLATFORM" "$fixed_tag" -o json > "outputs/grype/${fixed_safe_name}_grype.json" 2>/dev/null; then
      echo "    ✅ Grype scan successful with platform specification"
    else
      echo "    ⚠️ Failed with platform specification, trying without..."
      if grype "$fixed_tag" -o json > "outputs/grype/${fixed_safe_name}_grype.json" 2>/dev/null; then
        echo "    ✅ Grype scan successful without platform specification"
      else
        echo "    ❌ Grype scan failed for $fixed_tag"
        echo "    ℹ️ Creating empty file to avoid repeated failures"
        echo "{\"matches\": []}" > "outputs/grype/${fixed_safe_name}_grype.json"
      fi
    fi
  else
    # Grype doesn't support platform flag
    if grype "$fixed_tag" -o json > "outputs/grype/${fixed_safe_name}_grype.json" 2>/dev/null; then
      echo "    ✅ Grype scan successful"
    else
      echo "    ❌ Grype scan failed for $fixed_tag"
      echo "    ℹ️ Creating empty file to avoid repeated failures"
      echo "{\"matches\": []}" > "outputs/grype/${fixed_safe_name}_grype.json"
    fi
  fi
done

echo "✅ Fixed image creation complete. Results are in fixed_images/ directory"
echo "✅ Vulnerability scans for fixed images are in outputs/{syft,grype}/"

echo "Generating updated vulnerability report..."
python3 generate_report.py

echo "🌐 Open vulnerability_report.html in your browser to view critical vulnerabilities"
