#!/usr/bin/env python3

import json
import os
from pathlib import Path

def load_grype_results():
    results = []
    grype_dir = Path("outputs/grype")

    # Track original and fixed images
    original_images = set()
    fixed_images = set()

    for file in grype_dir.glob("*.json"):
        if file.stat().st_size == 0:
            print(f"Skipping empty file: {file.name}")
            continue
        try:
            with open(file) as f:
                data = json.load(f)
        except json.JSONDecodeError:
            print(f"Skipping invalid JSON file: {file.name}")
            continue

        image_name = file.stem.replace("_grype", "").replace("__", "/").replace("_", ":")

        # Determine if this is a fixed image
        is_fixed = "-fixed" in image_name

        # Store image name in appropriate set
        if is_fixed:
            fixed_images.add(image_name.replace("-fixed", ""))
        else:
            original_images.add(image_name)

        for match in data.get("matches", []):
            vuln = match.get("vulnerability", {})
            results.append({
                "image": image_name,
                "is_fixed": is_fixed,
                "cve": vuln.get("id", "N/A"),
                "severity": vuln.get("severity", "Unknown"),
                "package": match.get("artifact", {}).get("name", "N/A"),
                "version": match.get("artifact", {}).get("version", "N/A"),
                "description": vuln.get("description", "No description available")[:200] + "..."
            })

    severity_order = {"Critical": 0, "High": 1, "Medium": 2, "Low": 3, "Negligible": 4, "Unknown": 5}
    return sorted(results, key=lambda x: (severity_order.get(x["severity"], 5), x["is_fixed"]))

def generate_html(vulnerabilities):
    severity_colors = {
        "Critical": "#dc3545", "High": "#fd7e14", "Medium": "#ffc107", 
        "Low": "#28a745", "Negligible": "#6c757d", "Unknown": "#6f42c1"
    }

    # Separate original and fixed vulnerabilities
    original_vulns = [v for v in vulnerabilities if not v['is_fixed']]
    fixed_vulns = [v for v in vulnerabilities if v['is_fixed']]

    # Calculate statistics
    original_total = len(original_vulns)
    fixed_total = len(fixed_vulns)

    original_critical = sum(1 for v in original_vulns if v['severity'] == 'Critical')
    fixed_critical = sum(1 for v in fixed_vulns if v['severity'] == 'Critical')

    original_high = sum(1 for v in original_vulns if v['severity'] == 'High')
    fixed_high = sum(1 for v in fixed_vulns if v['severity'] == 'High')

    # Calculate reduction percentages
    total_reduction = ((original_total - fixed_total) / original_total * 100) if original_total > 0 else 0
    critical_reduction = ((original_critical - fixed_critical) / original_critical * 100) if original_critical > 0 else 0
    high_reduction = ((original_high - fixed_high) / original_high * 100) if original_high > 0 else 0

    # Calculate per-image statistics
    # Group vulnerabilities by image
    original_by_image = {}
    fixed_by_image = {}

    # Process original images
    for vuln in original_vulns:
        image_name = vuln['image']
        if image_name not in original_by_image:
            original_by_image[image_name] = {
                'total': 0,
                'critical': 0,
                'high': 0,
                'medium': 0,
                'low': 0,
                'negligible': 0,
                'unknown': 0
            }
        original_by_image[image_name]['total'] += 1
        severity = vuln['severity'].lower()
        if severity in original_by_image[image_name]:
            original_by_image[image_name][severity] += 1

    # Process fixed images
    for vuln in fixed_vulns:
        # Remove "-fixed" suffix to match with original image name
        image_name = vuln['image'].replace('-fixed', '')
        if image_name not in fixed_by_image:
            fixed_by_image[image_name] = {
                'total': 0,
                'critical': 0,
                'high': 0,
                'medium': 0,
                'low': 0,
                'negligible': 0,
                'unknown': 0
            }
        fixed_by_image[image_name]['total'] += 1
        severity = vuln['severity'].lower()
        if severity in fixed_by_image[image_name]:
            fixed_by_image[image_name][severity] += 1

    # Calculate improvements for each image
    image_improvements = []
    for image_name in original_by_image:
        original_count = original_by_image[image_name]['total']
        fixed_count = fixed_by_image.get(image_name, {'total': 0})['total']
        vulnerabilities_fixed = original_count - fixed_count
        improvement_percentage = (vulnerabilities_fixed / original_count * 100) if original_count > 0 else 0

        image_improvements.append({
            'image': image_name,
            'original_count': original_count,
            'fixed_count': fixed_count,
            'vulnerabilities_fixed': vulnerabilities_fixed,
            'improvement_percentage': improvement_percentage,
            'original_critical': original_by_image[image_name]['critical'],
            'fixed_critical': fixed_by_image.get(image_name, {'critical': 0})['critical'],
            'original_high': original_by_image[image_name]['high'],
            'fixed_high': fixed_by_image.get(image_name, {'high': 0})['high']
        })

    # Sort by improvement percentage (highest first)
    image_improvements.sort(key=lambda x: x['improvement_percentage'], reverse=True)

    html = f"""<!DOCTYPE html>
<html>
<head>
    <title>Container Vulnerability Report</title>
    <style>
        body {{ font-family: Arial, sans-serif; margin: 20px; }}
        .header {{ background: #f8f9fa; padding: 20px; border-radius: 5px; margin-bottom: 20px; }}
        .stats {{ display: flex; gap: 20px; margin-bottom: 20px; flex-wrap: wrap; }}
        .stat {{ background: white; padding: 15px; border-radius: 5px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); flex: 1; min-width: 200px; }}
        .comparison {{ display: flex; gap: 20px; margin-bottom: 20px; }}
        .comparison-column {{ flex: 1; }}
        table {{ width: 100%; border-collapse: collapse; }}
        th, td {{ padding: 10px; text-align: left; border-bottom: 1px solid #ddd; }}
        th {{ background: #f8f9fa; }}
        .severity {{ padding: 4px 8px; border-radius: 3px; color: white; font-weight: bold; }}
        .description {{ max-width: 300px; }}
        .fixed {{ background-color: #d4edda; }}
        .reduction {{ color: #28a745; font-weight: bold; }}
        .tabs {{ display: flex; margin-bottom: 20px; }}
        .tab {{ padding: 10px 20px; cursor: pointer; background: #f8f9fa; border: 1px solid #ddd; border-bottom: none; }}
        .tab.active {{ background: white; }}
        .tab-content {{ display: none; }}
        .tab-content.active {{ display: block; }}

        /* Dashboard styles */
        .dashboard-card {{ 
            background: white; 
            border-radius: 5px; 
            box-shadow: 0 2px 4px rgba(0,0,0,0.1); 
            padding: 15px; 
            margin-bottom: 15px; 
        }}
        .progress-container {{ 
            width: 100%; 
            background-color: #e9ecef; 
            border-radius: 4px; 
            margin: 5px 0; 
        }}
        .progress-bar {{ 
            height: 20px; 
            border-radius: 4px; 
            background-color: #28a745; 
            text-align: center; 
            color: white; 
            font-weight: bold; 
            line-height: 20px; 
            transition: width 0.5s ease-in-out;
        }}
        .dashboard-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }}
        .dashboard-table th {{
            text-align: center;
        }}
        .dashboard-table td {{
            text-align: center;
        }}
        .dashboard-table .image-name {{
            text-align: left;
            font-weight: bold;
        }}
    </style>
    <script>
        function showTab(tabId) {{
            // Hide all tab contents
            document.querySelectorAll('.tab-content').forEach(content => {{
                content.classList.remove('active');
            }});

            // Deactivate all tabs
            document.querySelectorAll('.tab').forEach(tab => {{
                tab.classList.remove('active');
            }});

            // Show selected tab content and activate tab
            document.getElementById(tabId).classList.add('active');
            // Use attribute selector with single quotes to avoid escaping issues
            document.querySelector('[onclick="showTab(\\'' + tabId + '\\')"]').classList.add('active');
        }}
    </script>
</head>
<body>
    <div class="header">
        <h1>Container Vulnerability Report</h1>
        <p>Comparison of original and fixed images</p>
    </div>

    <div class="stats">
        <div class="stat">
            <h3>Total Vulnerabilities</h3>
            <h2>{original_total} &rarr; {fixed_total} <span class="reduction">(-{total_reduction:.1f}%)</span></h2>
        </div>
        <div class="stat">
            <h3>Critical</h3>
            <h2 style="color: #dc3545">{original_critical} &rarr; {fixed_critical} <span class="reduction">(-{critical_reduction:.1f}%)</span></h2>
        </div>
        <div class="stat">
            <h3>High</h3>
            <h2 style="color: #fd7e14">{original_high} &rarr; {fixed_high} <span class="reduction">(-{high_reduction:.1f}%)</span></h2>
        </div>
    </div>

    <div class="tabs">
        <div class="tab active" onclick="showTab('dashboard-tab')">Dashboard</div>
        <div class="tab" onclick="showTab('original-tab')">Original Images</div>
        <div class="tab" onclick="showTab('fixed-tab')">Fixed Images</div>
        <div class="tab" onclick="showTab('all-tab')">All Vulnerabilities</div>
    </div>

    <div id="dashboard-tab" class="tab-content active">
        <h2>Vulnerability Remediation Dashboard</h2>

        <div class="stats">
            <div class="stat">
                <h3>Total Vulnerabilities Fixed</h3>
                <h2>{sum(img['vulnerabilities_fixed'] for img in image_improvements)} <span class="reduction">({total_reduction:.1f}%)</span></h2>
            </div>
            <div class="stat">
                <h3>Critical Vulnerabilities Fixed</h3>
                <h2 style="color: #dc3545">{original_critical - fixed_critical} <span class="reduction">({critical_reduction:.1f}%)</span></h2>
            </div>
            <div class="stat">
                <h3>High Vulnerabilities Fixed</h3>
                <h2 style="color: #fd7e14">{original_high - fixed_high} <span class="reduction">({high_reduction:.1f}%)</span></h2>
            </div>
        </div>

        <h3>Image Improvement Summary</h3>
        <table class="dashboard-table">
            <thead>
                <tr>
                    <th>Image</th>
                    <th>Original Vulnerabilities</th>
                    <th>Fixed Vulnerabilities</th>
                    <th>Vulnerabilities Fixed</th>
                    <th>Improvement</th>
                </tr>
            </thead>
            <tbody>"""

    # Add rows for each image
    for img in image_improvements:
        html += f"""
                <tr>
                    <td class="image-name">{img['image']}</td>
                    <td>{img['original_count']}</td>
                    <td>{img['fixed_count']}</td>
                    <td>{img['vulnerabilities_fixed']}</td>
                    <td><span class="reduction">({img['improvement_percentage']:.1f}%)</span></td>
                </tr>"""

    html += """
            </tbody>
        </table>

        <h3>Detailed Image Improvements</h3>
        <div class="dashboard-grid">"""

    # Add cards for each image
    for img in image_improvements:
        progress_width = min(100, max(0, img['improvement_percentage']))
        html += f"""
            <div class="dashboard-card">
                <h3>{img['image']}</h3>
                <p><strong>Vulnerabilities:</strong> {img['original_count']} &rarr; {img['fixed_count']} <span class="reduction">(-{img['vulnerabilities_fixed']})</span></p>
                <p><strong>Critical:</strong> {img['original_critical']} &rarr; {img['fixed_critical']} <span class="reduction">(-{img['original_critical'] - img['fixed_critical']})</span></p>
                <p><strong>High:</strong> {img['original_high']} &rarr; {img['fixed_high']} <span class="reduction">(-{img['original_high'] - img['fixed_high']})</span></p>

                <p><strong>Improvement: {img['improvement_percentage']:.1f}%</strong></p>
                <div class="progress-container">
                    <div class="progress-bar" style="width: {progress_width}%">{img['improvement_percentage']:.1f}%</div>
                </div>
            </div>"""

    html += """
        </div>
    </div>

    <div id="original-tab" class="tab-content">
        <h2>Original Images - Top {min(50, len(original_vulns))} Critical Vulnerabilities</h2>
        <table>
            <thead>
                <tr>
                    <th>Image</th>
                    <th>CVE</th>
                    <th>Severity</th>
                    <th>Package</th>
                    <th>Version</th>
                    <th>Description</th>
                </tr>
            </thead>
            <tbody>"""

    # Original images tab
    for vuln in original_vulns[:50]:  # Show top 50 most critical
        color = severity_colors.get(vuln["severity"], "#6c757d")
        html += f"""
            <tr>
                <td><strong>{vuln['image']}</strong></td>
                <td><a href="https://cve.mitre.org/cgi-bin/cvename.cgi?name={vuln['cve']}" target="_blank">{vuln['cve']}</a></td>
                <td><span class="severity" style="background-color: {color}">{vuln['severity']}</span></td>
                <td>{vuln['package']}</td>
                <td>{vuln['version']}</td>
                <td class="description">{vuln['description']}</td>
            </tr>"""

    html += """
        </tbody>
    </table>
    </div>

    <div id="fixed-tab" class="tab-content">
        <h2>Fixed Images - Remaining Vulnerabilities</h2>
        <table>
            <thead>
                <tr>
                    <th>Image</th>
                    <th>CVE</th>
                    <th>Severity</th>
                    <th>Package</th>
                    <th>Version</th>
                    <th>Description</th>
                </tr>
            </thead>
            <tbody>"""

    # Fixed images tab
    for vuln in fixed_vulns[:50]:  # Show top 50 most critical
        color = severity_colors.get(vuln["severity"], "#6c757d")
        html += f"""
            <tr class="fixed">
                <td><strong>{vuln['image']}</strong></td>
                <td><a href="https://cve.mitre.org/cgi-bin/cvename.cgi?name={vuln['cve']}" target="_blank">{vuln['cve']}</a></td>
                <td><span class="severity" style="background-color: {color}">{vuln['severity']}</span></td>
                <td>{vuln['package']}</td>
                <td>{vuln['version']}</td>
                <td class="description">{vuln['description']}</td>
            </tr>"""

    html += """
        </tbody>
    </table>
    </div>

    <div id="all-tab" class="tab-content">
        <h2>All Vulnerabilities</h2>
        <table>
            <thead>
                <tr>
                    <th>Image</th>
                    <th>CVE</th>
                    <th>Severity</th>
                    <th>Package</th>
                    <th>Version</th>
                    <th>Description</th>
                </tr>
            </thead>
            <tbody>"""

    # All vulnerabilities tab
    for vuln in vulnerabilities[:100]:  # Show top 100 most critical
        color = severity_colors.get(vuln["severity"], "#6c757d")
        row_class = "fixed" if vuln["is_fixed"] else ""
        html += f"""
            <tr class="{row_class}">
                <td><strong>{vuln['image']}</strong></td>
                <td><a href="https://cve.mitre.org/cgi-bin/cvename.cgi?name={vuln['cve']}" target="_blank">{vuln['cve']}</a></td>
                <td><span class="severity" style="background-color: {color}">{vuln['severity']}</span></td>
                <td>{vuln['package']}</td>
                <td>{vuln['version']}</td>
                <td class="description">{vuln['description']}</td>
            </tr>"""

    html += """
        </tbody>
    </table>
    </div>
</body>
</html>"""

    return html

if __name__ == "__main__":
    vulnerabilities = load_grype_results()
    html_content = generate_html(vulnerabilities)

    with open("vulnerability_report.html", "w") as f:
        f.write(html_content)

    print(f"📊 Generated vulnerability_report.html with {len(vulnerabilities)} vulnerabilities")
    print("🌐 Open vulnerability_report.html in your browser to view the report")
